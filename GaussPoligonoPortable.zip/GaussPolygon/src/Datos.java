import javax.swing.JTextField;

/**
 * * Esta clase convierte los datos ingresados en valores numericos y 
 * calcula el area de un poligono irregular con sus coordenadas X e Y

 * @author: Cecilia B.

 * @version: 10/06/2020/A
 */

public class Datos {

	/**
	 * Atributos de Datos
	 */
	private static String coordsX;
	private static String coordsY;
	
	/**
	 * Setter de coordenadas X de Datos
	 * @param String, obtenido de valores ingresados en coordsX de la clase Ventana1
	 */
	public static void setCoordsXDatos(String l) {
		coordsX = Ventana1.getCoordsX().getText().replaceAll("\\s+","");
		l = coordsX;
	}
	
	/**
	 * Setter de coordenadas Y de Datos
	 * @param String, obtenido de valores ingresados en coordsX de la clase Ventana1
	 */
	public static void setCoordsYDatos(String p) {
		coordsY = Ventana1.getCoordsY().getText().replaceAll("\\s+","");
		p = coordsY;
	}
		
	/**
	 * Getter de coordenadas X de Datos
	 * @return un array de doubles a partir de un String
	 */
	public static double[] getCoordsXDatos() {
		coordsX = Ventana1.getCoordsX().getText().replaceAll("\\s+","");
		String[] coordsXS = coordsX.split(",");
		double[] coordsXD = new double[coordsXS.length];
		for(int i = 0; i < coordsXS.length; i++) {
		    try {
		    	
		    	coordsXD[i] = Double.parseDouble(coordsXS[i]);

		    } catch (NumberFormatException e) {
		       // The string does not contain a parsable integer.
		    }
		}
		return coordsXD;
	}
	
	/**
	 * Getter de coordenadas Y de Datos
	 * @return un array de doubles a partir de un String
	 */
	public static double[] getCoordsYDatos() {
		coordsY = Ventana1.getCoordsY().getText().replaceAll("\\s+","");
		String[] coordsYS = coordsY.split(",");
		double[] coordsYD = new double[coordsYS.length];
		for(int i = 0; i < coordsYD.length; i++) {
		    try {
		    	coordsYD[i] = Double.parseDouble(coordsYS[i]);
		    } catch (NumberFormatException e) {
		       // The string does not contain a parsable integer.
		    }
		}
		return coordsYD;
	}
	
	/**
	 * Recorrer el bucle multiplicando cada elemento x * y+1 y viceversa
	 * @return un array de doubles con la multiplicacion de elementos a partir de dos arrays de doubles
	 */
	public static double[] recorrerCoordsDatos(double[] x, double[] y) {
		double[] tmp = new double[x.length];
		double s = 0;
		for(int i=0; i<=x.length-2;i++) {
				s = x[i]*y[i+1];
				tmp[i] = s;
				
		}
		tmp[x.length-1] = x[x.length-1]*y[0];
		
		return tmp;		
	}
	
	/**
	 * Sums all elements from the double array
	 * @param un array de doubles
	 * @return valor numerico double como sumatoria
	 */
	public static double sumatoriaDatos(double[] tmp) {
		double sum = 0;
		for(int i=0; i<tmp.length; i++) {
			sum += tmp[i];
		}
		return sum;
	}
	
	
}
