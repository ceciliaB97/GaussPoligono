import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal {

	public static void main(String[] args) {
		
		Ventana1 window = new Ventana1();
		window.setVisible(true);
		Ventana1.main(args);
	}

}
